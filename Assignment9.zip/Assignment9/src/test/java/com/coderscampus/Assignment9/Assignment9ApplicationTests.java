package com.coderscampus.Assignment9;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assignment9ApplicationTests {

	@Test
	void contextLoads() {
	}

}
